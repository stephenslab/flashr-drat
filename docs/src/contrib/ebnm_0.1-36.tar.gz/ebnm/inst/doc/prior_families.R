## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, fig.width = 7, fig.height = 5)

## ----sampling_fns-------------------------------------------------------------
# 'mb.times' sets 'times' for microbenchmark. The default is set to be small 
#   so that the vignette runs quickly, but much better results will be obtained 
#   when it's larger.
mb.times <- 5L 

library(ebnm)
library(microbenchmark)
library(ggplot2)

sample <- function(g, ...) {
  UseMethod("sample", g)
}

sample.normalmix <- function(g, nsamp) {
  which.comp <- rmultinom(nsamp, size = 1, prob = g$pi)
  means <- g$mean %*% which.comp
  sds <- g$sd %*% which.comp
  return(rnorm(nsamp, means, sds))
}

sample.unimix <- function(g, nsamp) {
  which.comp <- rmultinom(nsamp, size = 1, prob = g$pi)
  a <- g$a %*% which.comp
  b <- g$b %*% which.comp
  return(runif(nsamp, a, b))
}

cdf <- function(g, ...) {
  UseMethod("cdf", g)
}

cdf.normalmix <- function(g, x) {
  k <- length(g$pi)
  p <- matrix(pnorm(rep(x, each = k), g$mean, g$sd), nrow = k)
  return(as.vector(g$pi %*% p))
}
  
cdf.unimix <- function(g, x) {
  k <- length(g$pi)
  p <- matrix(punif(rep(x, each = k), g$a, g$b), nrow = k)
  return(as.vector(g$pi %*% p))
}

cdf.laplacemix <- function(g, x) {
  k <- length(g$pi)
  p <- matrix(0.5 * pexp(rep(x - g$mean[1], each = k), 1 / g$scale)
              + 0.5 * pexp(rep(-(x - g$mean[1]), each = k), 1 / g$scale, 
                           lower.tail = FALSE), 
              nrow = k)
  return(as.vector(g$pi %*% p))
}

plot.cdfs <- function(g.list, g.names, xmin, xmax, npts = 100) {
  grid <- seq(xmin, xmax, length.out = npts)
  cdf.list <- lapply(g.list, cdf, x = grid)
  df <- data.frame(x = rep(grid, length(g.list)),
                   cdf = unlist(cdf.list),
                   g = rep(g.names, each = length(grid)))
  ggplot(df, aes(x = x, y = cdf, color = g)) + geom_line()  
}

## ----g1.plot------------------------------------------------------------------
true.g <- ashr::normalmix(pi = c(0.6, 0.3, 0.1),
                          mean = c(0, 0, 0),
                          sd = c(0, 3, 10))

set.seed(666)
n <- 2000
theta <- sample(true.g, n)
s <- 1
x <- theta + rnorm(n)

n.res   <- ebnm_normal(x, s)
pn.res  <- ebnm_point_normal(x, s)
pl.res  <- ebnm_point_laplace(x, s)
smn.res <- ebnm_normal_scale_mixture(x, s)

plot.cdfs(list(true.g, n.res$fitted_g, pn.res$fitted_g, pl.res$fitted_g,
               smn.res$fitted_g),
          g.names = c("true.g", "normal", "point.normal", "point.laplace",
                      "scale.mix"),
          xmin = -10, xmax = 0.5)

## ----g1.timing.homo-----------------------------------------------------------
timing.res <- microbenchmark(ebnm_normal(x, s),
                             ebnm_point_normal(x, s),
                             ebnm_point_laplace(x, s),
                             ebnm_normal_scale_mixture(x, s),
                             ebnm_ash(x, s, mixcompdist = "normal"),
                             ebnm_unimodal_symmetric(x, s),
                             ebnm_unimodal(x, s),
                             times = mb.times)
autoplot(timing.res)

## ----g1.timing.hetero---------------------------------------------------------
s <- rgamma(n, 1, 1)
timing.res <- microbenchmark(ebnm_normal(x, s),
                             ebnm_point_normal(x, s),
                             ebnm_point_laplace(x, s),
                             ebnm_normal_scale_mixture(x, s),
                             ebnm_ash(x, s, mixcompdist = "normal"),
                             ebnm_unimodal_symmetric(x, s),
                             ebnm_unimodal(x, s),
                             times = mb.times)
autoplot(timing.res)

## ----g3.plot------------------------------------------------------------------
true.g <- ashr::normalmix(pi = c(0.8, 0.2),
                          mean = c(1, 1),
                          sd = c(0, 2))

n <- 2000
set.seed(666)
theta <- sample(true.g, n)
s <- 1
x <- theta + rnorm(n)

n.res   <- ebnm_normal(x, s, mode = "estimate")
pn.res  <- ebnm_point_normal(x, s, mode = "estimate")
pl.res  <- ebnm_point_laplace(x, s, mode = "estimate")
smn.res <- ebnm_normal_scale_mixture(x, s, mode = "estimate")

plot.cdfs(list(true.g, n.res$fitted_g, pn.res$fitted_g, pl.res$fitted_g,
               smn.res$fitted_g),
          g.names = c("true.g", "normal", "point.normal", "point.laplace",
                      "scale.mix"),
          xmin = -4, xmax = 1.5)

## ----g3.timing.homo-----------------------------------------------------------
timing.res <- microbenchmark(ebnm_normal(x, s, mode = "estimate"),
                             ebnm_point_normal(x, s, mode = "estimate"),
                             ebnm_point_laplace(x, s, mode = "estimate"),
                             ebnm_normal_scale_mixture(x, s, mode = "estimate"),
                             ebnm_ash(x, s, mixcompdist = "normal", mode = "estimate"),
                             ebnm_unimodal_symmetric(x, s, mode = "estimate"),
                             ebnm_unimodal(x, s, mode = "estimate"),
                             times = mb.times)
autoplot(timing.res)

## ----g3.timing.hetero---------------------------------------------------------
s <- rgamma(n, 1, 1)
timing.res <- microbenchmark(ebnm_normal(x, s, mode = "estimate"),
                             ebnm_point_normal(x, s, mode = "estimate"),
                             ebnm_point_laplace(x, s, mode = "estimate"),
                             ebnm_normal_scale_mixture(x, s, mode = "estimate"),
                             ebnm_ash(x, s, mixcompdist = "normal", mode = "estimate"),
                             ebnm_unimodal_symmetric(x, s, mode = "estimate"),
                             ebnm_unimodal(x, s, mode = "estimate"),
                             times = mb.times)
autoplot(timing.res)

