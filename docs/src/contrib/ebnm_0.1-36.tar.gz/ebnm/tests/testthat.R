library(testthat)
library(ebnm)

test_check("ebnm")
