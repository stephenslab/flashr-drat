## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE,comment = "#",collapse = TRUE,
  fig.align = "center",tidy = FALSE)

## -----------------------------------------------------------------------------
library(flashr)
set.seed(1)
n = 100
p = 500
k = 7
LL = matrix(rnorm(n*k), nrow=n)
FF = matrix(rnorm(p*k), nrow=p)
Y = LL %*% t(FF) + rnorm(n*p)

## -----------------------------------------------------------------------------
f = flash(Y, verbose=FALSE)
ldf = f$ldf
ldf$d

## -----------------------------------------------------------------------------
f.b = flash(Y, f_init = f, backfit=TRUE, greedy=FALSE, verbose=FALSE)
f.b$ldf$d

## -----------------------------------------------------------------------------
f.gb = flash(Y, backfit=TRUE, greedy=TRUE, verbose=FALSE)
f.gb$ldf$d

## ---- fig.width = 5, fig.height = 4-------------------------------------------
Ymiss=Y
Ymiss[1:20,1] = NA
f = flash(Ymiss, verbose=FALSE)
Ynew = flash_fill(Ymiss, f)
plot(Y[1:20,1],Ynew[1:20,1])

