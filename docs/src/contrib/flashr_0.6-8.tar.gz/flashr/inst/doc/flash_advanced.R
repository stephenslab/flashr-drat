## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE,comment = "#",collapse = TRUE,
  fig.align = "center",tidy = FALSE)

## -----------------------------------------------------------------------------
library(flashr)
set.seed(1)
n = 100
p = 500
k = 7
LL = matrix(rnorm(n*k),nrow=n)
FF = matrix(rnorm(p*k),nrow=p)
Y = LL %*% t(FF) + rnorm(n*p)

## -----------------------------------------------------------------------------
data = flash_set_data(Y)

## -----------------------------------------------------------------------------
f = flash_add_factors_from_data(data, K=10, backfit=FALSE)

## -----------------------------------------------------------------------------
f = flash_backfit(data, f, verbose=FALSE)

## ---- fig.width = 5, fig.height = 5-------------------------------------------
plot(f$fitted_values, LL %*% t(FF),
     main="compare fitted values with true LF'")
f$ldf$d
f$objective

## -----------------------------------------------------------------------------
f_greedy = flash_add_greedy(data, Kmax=10, verbose=FALSE)
f_greedy$ldf$d
f_greedy$objective

## -----------------------------------------------------------------------------
f_greedy_bf = flash_backfit(data, f_greedy, verbose=FALSE)
f_greedy_bf$ldf$d
f_greedy_bf$objective
f$objective

## -----------------------------------------------------------------------------
f_true = flash_add_factors_from_data(LL %*% t(FF), K=ncol(LL), 
                                      backfit=FALSE)
f_cheat = flash_backfit(data, f_init=f_true, verbose=FALSE)
f_cheat$ldf$d
f_cheat$objective

## -----------------------------------------------------------------------------
mean((f_cheat$fitted_values - LL %*% t(FF))^2)
mean((f_greedy_bf$fitted_values - LL %*% t(FF))^2)
mean((f$fitted_values - LL %*% t(FF))^2)
mean((f_greedy$fitted_values - LL %*% t(FF))^2)

## -----------------------------------------------------------------------------
f_greedy_ash = flash_add_greedy(data, Kmax=10, ebnm_fn="ebnm_ash",
                                verbose=FALSE)
f_greedy_ash$objective

## -----------------------------------------------------------------------------
f = flash_add_fixed_loadings(data, LL = cbind(rep(1,n)), backfit=TRUE,
                             verbose=FALSE)
f = flash_add_factors_from_data(data, K=10, f_init=f, backfit=TRUE,
                                verbose=FALSE)
f$nfactors # tells you how many nonzero factors f has
head(f$fit$EL[, 1])
# Note that factor is 0
head(f$fit$EF[, 1])

