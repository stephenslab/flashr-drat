library(testthat)
library(flashr)

test_check("flashr")
